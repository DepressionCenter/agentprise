---
name: __proto__
description: A skill named __proto__.
---

Nothing to see.
