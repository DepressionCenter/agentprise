---
name: safe
description: A harmless skill among hostile files.
---

Stay safe.
