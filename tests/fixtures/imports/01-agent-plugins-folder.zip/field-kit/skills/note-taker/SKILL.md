---
name: note-taker
description: Takes tidy field notes.
---

Write notes as short bullets.
