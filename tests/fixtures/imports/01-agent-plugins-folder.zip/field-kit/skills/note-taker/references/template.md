# Note template

- Date
- Place
- Observation
