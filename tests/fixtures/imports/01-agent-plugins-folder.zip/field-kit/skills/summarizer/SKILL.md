---
name: summarizer
description: Summarizes field notes.
---

Summarize in three sentences.
