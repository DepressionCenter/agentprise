---
description: A slash command.
---

Summarize today's notes.
