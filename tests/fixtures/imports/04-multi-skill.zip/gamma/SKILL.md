---
name: gamma
description: A sibling skill with its own license file.
---

Gamma body.
