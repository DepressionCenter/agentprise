---
name: alpha
description: The outer skill.
---

Alpha body.
