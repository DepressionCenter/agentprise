---
name: beta
description: A skill nested inside alpha.
---

Beta body.
