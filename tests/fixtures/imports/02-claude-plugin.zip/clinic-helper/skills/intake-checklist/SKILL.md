---
name: intake-checklist
description: Builds an intake checklist.
---

List each form the visit needs.
