---
name: lookup
description: Looks things up.
---

Search first, then answer.
