---
name: solo-helper
description: One skill at the root of a ZIP.
---

Help with one thing at a time.
