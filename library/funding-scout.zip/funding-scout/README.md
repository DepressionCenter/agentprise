<!--
Funding Scout
Copyright (C) 2026 Gabriel Mongefranco. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Funding Scout

Discover and verify funding opportunities, assess eligibility and interdisciplinary fit, and build a realistic application plan.

Made by Gabriel Mongefranco (https://gabriel.mongefranco.com).

## What is inside

- Funding Scout (assistant): skills/funding-scout/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
