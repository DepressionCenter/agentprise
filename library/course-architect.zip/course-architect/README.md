<!--
Course Architect
Copyright (C) 2026 Gabriel Mongefranco. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Course Architect

Build aligned lessons, authentic assignments, and fair rubrics with accessible materials and clear expectations for AI use.

Made by Gabriel Mongefranco (https://gabriel.mongefranco.com).

## What is inside

- Course Architect (assistant): skills/course-architect/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
