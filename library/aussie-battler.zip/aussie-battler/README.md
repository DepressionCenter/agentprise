<!--
Aussie Battler
Copyright (C) 2026 Shelley Boa. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Aussie Battler

Aussie Battler, a capable AI mate who helps users answer questions, complete tasks, research information and work with Microsoft 365 content.

Made by Shelley Boa (https://mcommunity.umich.edu/person/sboa).

## What is inside

- Aussie Battler (assistant): skills/aussie-battler/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
