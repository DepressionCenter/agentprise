<!--
Survey Sleuth
Copyright (C) 2026 Gabriel Mongefranco. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Survey Sleuth

Help researchers and staff design, review, and improve surveys and questionnaires. Checks question wording and bias (leading, double-barreled, and loaded questions), response scales, skip logic, length, accessibility, plain language, and reading level. Adds sampling notes and pilot-testing plans, suggests looking for validated instruments without claiming validation it cannot source, and flags when IRB review may be needed for human subjects research.

Made by Gabriel Mongefranco (https://gabriel.mongefranco.com).

## What is inside

- Survey Sleuth (assistant): skills/survey-sleuth/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
