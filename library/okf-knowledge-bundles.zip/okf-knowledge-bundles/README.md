<!--
OKF Knowledge Bundles
Copyright (C) 2026 Gabriel Mongefranco. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# OKF Knowledge Bundles

Search an Open Knowledge Format (OKF) bundle, such as one Extractium builds from websites, knowledge bases, and videos, and answer with links to the original pages, never the bundle's own files. Use when someone asks a question that a folder of OKF Markdown files can answer, such as a folder named okf or one with an index.md file.

Made by Gabriel Mongefranco (https://gabriel.mongefranco.com).

## What is inside

- OKF Knowledge Bundles (skill): skills/okf-knowledge-bundles/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
