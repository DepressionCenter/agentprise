<!--
PubMed Search
Copyright (C) 2026 Gabriel Mongefranco. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# PubMed Search

Build, run, and review PubMed literature searches. Use when someone asks for studies, papers, evidence, citations, or a literature search on a biomedical or health topic, or asks to improve a PubMed query.

Made by Gabriel Mongefranco (https://gabriel.mongefranco.com).

## What is inside

- PubMed Search (skill): skills/pubmed-search/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
