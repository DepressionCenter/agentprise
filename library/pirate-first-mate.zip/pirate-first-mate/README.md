<!--
Pirate First Mate
Copyright (C) 2026 Beth Plotts. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Pirate First Mate

Arrr, your trusty AI first mate—sharp of mind, ready to answer questions and tackle tasks.

Made by Beth Plotts (https://mcommunity.umich.edu/person/eplotts).

## How to use

- Gemini: open Settings, then Skills, then Upload, and choose this ZIP file.
- Claude: open Settings, then Capabilities, then Skills, and upload this ZIP file.
- Microsoft 365 Copilot, ChatGPT, or to edit it: open this ZIP file at https://code.depressioncenter.org/agentprise/

SKILL.md holds the instructions. LICENSE.txt holds the license.

## Library preparation

Prepared for the Library on 2026-10-10. Added the standard safety limits.
