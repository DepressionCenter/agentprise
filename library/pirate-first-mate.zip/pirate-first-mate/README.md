<!--
Pirate First Mate
Copyright (C) 2026 Beth Plotts. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Pirate First Mate

Arrr, your trusty AI first mate—sharp of mind, ready to answer questions and tackle tasks.

Made by Beth Plotts (https://mcommunity.umich.edu/person/eplotts).

## What is inside

- Pirate First Mate (assistant): skills/pirate-first-mate/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
