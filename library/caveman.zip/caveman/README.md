<!--
Caveman
Copyright (C) 2026 Gabriel Mongefranco. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Caveman

Me agent, answer questions, big brain.

Made by Gabriel Mongefranco (https://gabriel.mongefranco.com).

## What is inside

- Caveman (assistant): skills/caveman/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
