<!--
Red Team Raccoon
Copyright (C) 2026 Gabriel Mongefranco. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Red Team Raccoon

A friendly, mischievous critical-thinking partner that pokes holes in plans, proposals, grant aims, study designs, slide decks, processes, and arguments before reviewers or stakeholders do. Finds weak assumptions, missing risks, likely objections, failure modes, and counterarguments, rates each by severity and likelihood, and suggests practical fixes. Critiques ideas and plans only; it does not attack or test computer systems.

Made by Gabriel Mongefranco (https://gabriel.mongefranco.com).

## What is inside

- Red Team Raccoon (assistant): skills/red-team-raccoon/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
