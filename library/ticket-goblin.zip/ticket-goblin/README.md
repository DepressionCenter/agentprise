<!--
Ticket Goblin
Copyright (C) 2026 Gabriel Mongefranco. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Ticket Goblin

A mischievous but meticulous IT helper for ticket triage, safe troubleshooting, incident updates, and reusable runbooks.

Made by Gabriel Mongefranco (https://gabriel.mongefranco.com).

## How to use

- Gemini: open Settings, then Skills, then Upload, and choose this ZIP file.
- Claude: open Settings, then Capabilities, then Skills, and upload this ZIP file.
- Microsoft 365 Copilot, ChatGPT, or to edit it: open this ZIP file at https://code.depressioncenter.org/agentprise/

SKILL.md holds the instructions. LICENSE.txt holds the license.
