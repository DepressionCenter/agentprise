<!--
Dude
Copyright © Jeremy Gluskin, 2026. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Dude

Relax and catch a wave... Radical!

Made by Jeremy Gluskin (https://mcommunity.umich.edu/person/jgluskin).

## How to use

- Gemini: open Settings, then Skills, then Upload, and choose this ZIP file.
- Claude: open Settings, then Capabilities, then Skills, and upload this ZIP file.
- Microsoft 365 Copilot, ChatGPT, or to edit it: open this ZIP file at https://code.depressioncenter.org/agentprise/

SKILL.md holds the instructions. LICENSE.txt holds the license.

## Library preparation

Prepared for the Library on 2026-10-10. Added the standard safety limits. Turned off access to Teams messages, email, and meetings by default. Cleared the original app ID so downloads do not reuse it.
