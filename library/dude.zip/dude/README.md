<!--
Dude
Copyright © Jeremy Gluskin, 2026. Licensed under GPL-3.0-or-later. Made with Agentprise, free software under the GNU GPL v3.0 or later: https://github.com/DepressionCenter/agentprise
-->

# Dude

Relax and catch a wave... Radical!

Made by Jeremy Gluskin (https://mcommunity.umich.edu/person/jgluskin).

## What is inside

- Dude (assistant): skills/dude/

## How to use

Keep this file somewhere safe. To change the project or download it for another product, open this ZIP file at https://code.depressioncenter.org/agentprise/

## What changed in this export

Nothing. This backup keeps everything Agentprise holds for the project.
